<?php
include("connection.php");
$house_id = $_GET['id']; // get the house id from the URL parameter
$query = "select * from house where id = $house_id"; // select the house data from the database
$data = mysqli_query($conn,$query);
$result = mysqli_fetch_assoc($data);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="beforepayment.css">
    <link rel="stylesheet" href="modepay.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<title>Document</title>
<style>
    .header-booking{
        margin-top:50px
    }
    #wrapper
{
  border: 1px solid #888;
  display: inline-block;
  padding:20px;
  margin-top:100px
  margin-right:50 ;
  
}
.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #04AA6D;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
<title>Document</title>
   
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Paying Guest Accomodation System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="#">Hi <?php if(session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
;echo $_SESSION['uname'];?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="index.html">Sign Out</a>
      </li>
    </ul>
  </div>  
</nav>
<div>
<h1 style="text-align:center;">Select the Duration of your stay</h1>
</div>
<div class="header-booking" id="booking-1" role="form" aria-label="Make a Reservation" >
  <form class="booking" name="booking" method="get" target="_blank" action="//ichotelsgroup.com/redirect">
      <div class="booking-input date">
          <input type="date" class="arrival" name="arrivaldate" aria-label="Arrival Date">
          <i class="fa-regular fa-calendar-days"></i>
      </div>

      <div class="booking-input date">
          <input type="date" class="departure" name="departuredate" aria-label="Departure Date">
          <i class="fa-regular fa-calendar-days"></i>
      </div>
    

      <input type="hidden" name="checkInDate" value="">
      <input type="hidden" name="checkOutDate" value="">
      <input type="hidden" name="checkInMonthYear" value="">
      <input type="hidden" name="checkOutMonthYear" value="">
      <input type="hidden" name="path" value="rates">
      <input type="hidden" name="brandCode" value="hi">
      <input type="hidden" name="numberOfAdults" value="1">
      <input type="hidden" name="numberOfChildren" value="0">
      <input type="hidden" name="numberOfRooms" value="1">
      <input type="hidden" name="rateCode" value="6CBARC">
      <input type="hidden" name="hotelCode" value="dislb">
      <input type="hidden" name="_PMID" value="99502222">

      

  </form>
</div>
<div id="wrapper">
  <label for="yes_no_radio">Do you agree to the terms?</label>
<p>
<input type="radio" name="yes_no" checked>Yes</input>
</p>
<p>
<input type="radio" name="yes_no">No</input>
</p>
</div>

<div class="badan">
<button type="button" class="btn" data-toggle="modal" data-target="#modal-lg">Show Payment Method</button>
</div>
<div class="modal fade bd-example-modal-lg" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Payment Method</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body p-0">
              <div class="container">
                  <div class="grid-wrapper grid-col-auto">
                    <label for="radio-card-1" class="radio-card">
                      <input type="radio" name="radio-card" id="radio-card-1" checked />
                      <div class="card-content-wrapper">
                        <span class="check-icon"></span>
                        <div class="card-content text-center">
                          <img src="https://www.bca.co.id/-/media/Feature/Header/Header-Logo/logo-bca.svg?"
                            class="img-fluid" />
                          <h4>BCA</h4>
                        </div>
                      </div>
                    </label>
                    <!-- /.radio-card -->
                    <label for="radio-card-2" class="radio-card">
                      <input type="radio" name="radio-card" id="radio-card-2" />
                      <div class="card-content-wrapper">
                        <span class="check-icon"></span>
                        <div class="card-content text-center">
                          <img src="https://bankmandiri.co.id/image/layout_set_logo?img_id=31567&t=1678035789124"
                            class="img-fluid" />
                          <h4>Mandiri</h4>
                        </div>
                      </div>
                    </label>
                    <!-- /.radio-card -->
                    <label for="radio-card-3" class="radio-card">
                      <input type="radio" name="radio-card" id="radio-card-3" />
                      <div class="card-content-wrapper">
                        <span class="check-icon"></span>
                        <div class="card-content text-center">
                          <img src="https://bri.co.id/o/bri-corporate-theme/images/bri-logo.png"
                            class="img-fluid" />
                          <h4>BRI</h4>
                        </div>
                      </div>
                    </label>
                    <!-- /.radio-card -->
                    <label for="radio-card-4" class="radio-card">
                      <input type="radio" name="radio-card" id="radio-card-4" />
                      <div class="card-content-wrapper">
                        <span class="check-icon"></span>
                        <div class="card-content text-center">
                          <img src="https://www.bni.co.id/Portals/1/bni-logo-id.png"
                            class="img-fluid" />
                          <h4>BNI</h4>
                        </div>
                      </div>
                    </label>
                    <!-- /.radio-card -->
                    <label for="radio-card-5" class="radio-card">
                      <input type="radio" name="radio-card" id="radio-card-5" />
                      <div class="card-content-wrapper">
                        <span class="check-icon"></span>
                        <div class="card-content text-center">
                          <img src="https://cdn-icons-png.flaticon.com/512/2175/2175515.png"
                            class="img-fluid" />
                          <h4>Others</h4>
                        </div>
                      </div>
                    </label>
                    <!-- /.radio-card -->

                  </div>
                  <!-- /.grid-wrapper -->
                </div>
            </div>
            <div class="modal-footer justify-content-end p-0">
													<button type="button" class="btn-outline-light m-0" data-dismiss="modal" aria-label="Close">Cancel</button>
              <button type="button" class="btn-outline-primary m-0" data-dismiss="modal" aria-label="Close"  onclick="window.location.href='checkout.php?id=<?php echo $result['id'] ?>'">Apply</button>
              
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <?php
// Include the database connection file
require_once("connection.php");

// Check if the 'id' parameter is set and is a valid integer
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    // Sanitize the 'id' parameter to prevent SQL injection attacks
    $house_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Construct the SQL query to select the house data from the database
    $query = "SELECT * FROM house WHERE id = $house_id";

    // Execute the query and check for errors
    if ($result = mysqli_query($conn, $query)) {
        // Check if the query returned any results
        if (mysqli_num_rows($result) > 0) {
            // Fetch the result as an associative array
            $house_data = mysqli_fetch_assoc($result);
            $total_price = $house_data['rate'];
        } else {
            // Handle the case where the query returned no results
            die("No house found with id $house_id");
        }
    } else {
        // Handle the case where the query failed
        die("Query failed: " . mysqli_error($conn));
    }
} else {
    // Handle the case where the 'id' parameter is missing or invalid
    die("Invalid house id");
}

echo '<div class="col-25">
<div class="container">
        <h4>Bill <span class="price" style="color:black"><b></b></span></h4>
        <p><a href="#">House Rent </a> <span class="price">'.$house_data['rate'].'</span></p>
        <p><a href="#">Tiffin Rent</a> <span class="price">00</span></p>
        <p><a href="#">Deposit</a> <span class="price">00</span></p>
        <hr>
        
        <p>Total <span class="price" style="color:black"><b>'. $total_price .'</b></span></p>
    </div>
</div>';
?>

</body>
</html>